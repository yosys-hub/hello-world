const jsonServer = require("json-server");
const fs = require("fs");
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");
const helmet = require("helmet");
const request = require("request")

// JSON Serverで使用するJSONファイルを設定
const server = jsonServer.create();
const router = jsonServer.router("./DB/db.json");
// JSON形式のリクエスト対応
server.use(bodyParser.urlencoded({ extended: true }));
server.use(bodyParser.json());

// 署名
const JWT_SECRET = "jwt_json_server";
// 有効時間
const EXPIRATION = "1h";
const hostname = "0.0.0.0"
const port = 3001

// データーベースの作成
const db = JSON.parse(fs.readFileSync("./DB/db.json", "UTF-8"));

// ①ログイン用のルート
server.post("/auth/login", (req, resp,next) => {
    console.log("server.post")
    const { email, password } = req.body;
    // ログイン検証
    if (db.account.findIndex( (user) => user.email === email && user.password === password ) === -1 ) {      
        resp.status(401).json("Unauthorized");
        return;
    }

    // ログイン後、アクセストークンの生成
    const access_token = jwt.sign({ email, password }, JWT_SECRET, {
        expiresIn: EXPIRATION,
    });
//    resp.status(200).json({ access_token });
    console.log(access_token)
    console.log("-----------------------------")
    resp.cookie('jwt',access_token)
//    sendAuthRequest("http://localhost:3000/login","POST",access_token)
    resp.redirect(307,'http://localhost:3000/login')
});

//③ 認証が必要なルート
server.use((req, resp, next) => {
    console.log("server.use")
    // 認証形式チェック
    if ( req.headers.authorization === undefined ){
        resp.status(401).json("Fail:auth_Undefined");
    } else if (req.headers.authorization.split(" ")[0] !== "Bearer" ) {
        resp.status(401).json("Fail:Invalid value");
      // 認証形式が異なる場合
    }else{
        // 認証チェック
        try {
        var decode = jwt.verify( req.headers.authorization.split(" ")[1], JWT_SECRET );
        // 認証に成功した場合は、next関数を実行しJSON Serverの機能を利用する

        next();
        } catch (e) {
        // 認証に失敗した場合
        resp.status(401).json("Unauthorized");
        }
    }
});


function sendAuthRequest(ur,mtd,tkn) {
    console.log("sendauthrequest")
    console.log("--------------------")

    var options ={
        url: ur,
        method: mtd,
        headers: {
            Authorization: tkn
        }
    }
    request(options,function(error,res,body){
        console.log(body)
    })
}

// JSON Serverを起動する
server.use(router);
server.use(helmet);
server.listen(port, hostname, () => {
  console.log("JSON Server Start");
});