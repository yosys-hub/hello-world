const express = require('express');
const app = express()
const path = require('path');

const port = 3000;

app.use(express.static(path.join(__dirname, 'public')));
// ServerObjectの作成
// requestイベントにdoRequestを割り当て
// ※requestはhttp.Serverオブジェクトがクライアントから
// 　リクエストを受け取ったときに発生するイベント

app.post('/login', (req,res) =>{
  console.log("req.headers")
  console.log(`----------------------`)
  console.log(req.headers.authorization )
//  res.cookie('jwt',req.headers.authorization)
  res.render('./index.ejs')
});

// port:3000でサーバー待ち
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
} );